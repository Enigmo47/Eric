# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime, timedelta


class jugador(models.Model):
    _name = 'club_baloncesto_eric.jugador'
    _description = 'club_baloncesto_eric.club_baloncesto_eric'

    nombre = fields.Char()
    apellido = fields.Char()
    birthdate = fields.Date()
    age = fields.Integer(compute="age_calc", store=True)
    category = fields.Char(compute="category_calc", store=True)
    mail = fields.Char()
    parentsP = fields.Integer()
    phone = fields.Integer()
    equipo= fields.Many2many("club_baloncesto_eric.equipo",'jugador')
    entreno = fields.Char()
    


    @api.depends('birthdate')
    def age_calc(self):
            if self.birthdate is not False :
                self.age = (datetime.today().date() - datetime.strptime(str(self.birthdate), '%Y-%m-%d').date()) // timedelta(days=365)
    
    @api.depends('age')
    def category_calc(self):
        if self.age < 8 or self.age > 17:
            self.category = "-"
        elif self.age < 11:
            self.category = ("alevin")
        elif self.age < 14:
            self.category = ("infantil")
        elif self.age < 16:
            self.category = ("cadete")            
        else:
            self.category = ("juvenil")

class entrenador(models.Model):
    _name = 'club_baloncesto_eric.entrenador'
    _description = 'informacion de los entrendores del club'

    nombre = fields.Char()
    apellido = fields.Char()
    dni = fields.Char()
    telefono = fields.Integer()
    mail = fields.Char()
    equipo= fields.Many2one("club_baloncesto_eric.equipo")
    entreno = fields.Char()
    

class equipo(models.Model):
    _name = 'club_baloncesto_eric.equipo'
    _description = 'informacion de los equipos'

    nombre = fields.Char()

    jugador= fields.Many2many("club_baloncesto_eric.jugador",'equipo')
    entrenador= fields.One2many("club_baloncesto_eric.entrenador",'equipo')

    




# -*- coding: utf-8 -*-

#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100