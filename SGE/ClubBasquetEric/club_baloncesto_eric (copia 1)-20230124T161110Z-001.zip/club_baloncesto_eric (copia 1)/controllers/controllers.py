# -*- coding: utf-8 -*-
# from odoo import http


# class ClubBaloncestoEric(http.Controller):
#     @http.route('/club_baloncesto_eric/club_baloncesto_eric/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/club_baloncesto_eric/club_baloncesto_eric/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('club_baloncesto_eric.listing', {
#             'root': '/club_baloncesto_eric/club_baloncesto_eric',
#             'objects': http.request.env['club_baloncesto_eric.club_baloncesto_eric'].search([]),
#         })

#     @http.route('/club_baloncesto_eric/club_baloncesto_eric/objects/<model("club_baloncesto_eric.club_baloncesto_eric"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('club_baloncesto_eric.object', {
#             'object': obj
#         })
